服务器流量监控小工具
====

### 安装： 

```shell script
$ pip install netrec
```

### 使用：

```shell script
$ netrec [-选项]

# 显示帮助
$ netrec -h
```

### 参数介绍：  
懒得写了，看帮助吧
